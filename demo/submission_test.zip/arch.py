"""
Place the code for your architecture here...


Please provide a function srmodel() which returns your configured and initialized network.

def srmodel():
    # init model object
    ...
    # load checkpoints
    ...
    
    return model
"""